import React, { useState } from 'react';
import { EmailClient } from './components/EmailClient';
import { Sidebar } from './components/Sidebar';
import { Email, Attachment } from './types';

// Mock Data for testing
const MOCK_EMAILS: Email[] = [
  {
    id: '1',
    sender: 'Sarah Jenkins',
    subject: 'Project Alpha Q3 Update - Important',
    date: '10:42 AM',
    avatar: 'S',
    body: `Hi Team,

I wanted to provide a quick update on Project Alpha regarding our Q3 milestones. We are currently tracking ahead of schedule on the backend infrastructure migration, but the frontend redesign is lagging slightly behind due to resource constraints.

Key Highlights:
1. Database migration completed successfully with zero downtime.
2. New API endpoints are live and documented.
3. User Acceptance Testing (UAT) is scheduled for next Tuesday.

Action Items:
- Please review the attached architectural diagrams.
- @Mike, can you confirm if the load balancer configurations are finalized?
- @Jessica, we need the updated Figma mocks by Friday EOD.

Let's convene for a standup tomorrow at 9 AM to discuss blockers.

Best,
Sarah`,
    attachments: [
        { id: 'a1', name: 'Architecture_Diagram_v3.pdf', type: 'pdf', size: '2.4 MB' },
        { id: 'a2', name: 'Q3_Timeline.xlsx', type: 'sheet', size: '1.1 MB' }
    ]
  },
  {
    id: '2',
    sender: 'Cloud Services Billing',
    subject: 'Invoice #INV-2024-001 Pending Payment',
    date: 'Yesterday',
    avatar: 'C',
    body: `Dear Customer,

This is a reminder that your invoice #INV-2024-001 for the amount of $450.00 was due on Oct 1st. 

Services included:
- Compute Instance (Large) - 750 Hours
- Storage Block (1TB)
- Data Transfer Out

Please ensure payment is made within 3 business days to avoid service interruption. You can pay directly via our portal.

Regards,
Billing Team`,
    attachments: [
        { id: 'a3', name: 'Invoice_INV-2024-001.pdf', type: 'pdf', size: '450 KB' }
    ]
  },
  {
    id: '3',
    sender: 'Hugging Face Notifications',
    subject: 'Your model training is complete',
    date: 'Oct 2',
    avatar: 'H',
    body: `Hello Developer,

Great news! Your fine-tuning job 'bart-large-cnn-custom' has finished successfully. 

Metrics:
- Loss: 0.145
- Accuracy: 92.4%
- Training Time: 4h 20m

You can now deploy this model to an Inference Endpoint. Click here to view the training logs.

Happy Building!
The Hugging Face Team`
  },
  {
    id: '4',
    sender: 'Jason from Marketing',
    subject: 'Q4 Campaign Ideas',
    date: 'Oct 1',
    avatar: 'J',
    body: `Hey all,

I've been brainstorming some ideas for the upcoming holiday season. 
1. Social media contest with giveaways.
2. Email drip campaign focusing on new features.
3. Partnership with local influencers.

Let me know what you think so we can start budgeting.

Cheers,
Jason`,
    attachments: [
        { id: 'a4', name: 'Draft_Campaign_Ideas.docx', type: 'doc', size: '28 KB' },
        { id: 'a5', name: 'Influencer_List.xlsx', type: 'sheet', size: '15 KB' }
    ]
  }
];

const App: React.FC = () => {
  const [selectedEmailId, setSelectedEmailId] = useState<string | null>('1');
  const [checkedEmailIds, setCheckedEmailIds] = useState<Set<string>>(new Set());
  
  // Extension State
  const [sidebarTab, setSidebarTab] = useState<'summary' | 'reply' | 'files'>('summary');
  const [selectedFile, setSelectedFile] = useState<Attachment | null>(null);

  // Logic: 
  // If emails are checked, the sidebar focuses on those.
  // If no emails are checked, the sidebar focuses on the currently opened email.
  const emailsToProcess = checkedEmailIds.size > 0 
    ? MOCK_EMAILS.filter(e => checkedEmailIds.has(e.id))
    : (selectedEmailId ? MOCK_EMAILS.filter(e => e.id === selectedEmailId) : []);

  const handleToggleCheck = (id: string) => {
    const newChecked = new Set(checkedEmailIds);
    if (newChecked.has(id)) {
      newChecked.delete(id);
    } else {
      newChecked.add(id);
    }
    setCheckedEmailIds(newChecked);
  };

  const handleAttachmentClick = (attachment: Attachment) => {
      setSelectedFile(attachment);
      setSidebarTab('files');
  };

  return (
    <div className="flex w-full h-full bg-[#0C1014] overflow-hidden font-sans text-white">
      {/* 
        This layout simulates the browser window.
        Left side: The "Website" (Gmail)
        Right side: The "Extension" (Sidebar)
      */}
      
      {/* Main Website Content */}
      <EmailClient 
        emails={MOCK_EMAILS} 
        selectedEmailId={selectedEmailId} 
        checkedEmailIds={checkedEmailIds}
        onSelectEmail={setSelectedEmailId} 
        onToggleCheck={handleToggleCheck}
        onAttachmentClick={handleAttachmentClick}
      />

      {/* Extension Sidebar Overlay */}
      <Sidebar 
        targetEmails={emailsToProcess} 
        selectedFile={selectedFile}
        activeTab={sidebarTab}
        setActiveTab={setSidebarTab}
      />
    </div>
  );
};

export default App;