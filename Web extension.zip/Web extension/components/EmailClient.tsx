import React from 'react';
import { Email, Attachment } from '../types';
import { Star, Menu, Search, HelpCircle, Settings, Grid, Paperclip, FileText, Image, FileSpreadsheet } from 'lucide-react';

interface EmailClientProps {
  emails: Email[];
  selectedEmailId: string | null;
  checkedEmailIds: Set<string>;
  onSelectEmail: (id: string) => void;
  onToggleCheck: (id: string) => void;
  onAttachmentClick: (attachment: Attachment) => void;
}

const getFileIcon = (type: string) => {
  switch (type) {
    case 'pdf': return <FileText size={20} className="text-red-500" />;
    case 'doc': return <FileText size={20} className="text-blue-500" />;
    case 'sheet': return <FileSpreadsheet size={20} className="text-green-500" />;
    case 'image': return <Image size={20} className="text-purple-500" />;
    default: return <Paperclip size={20} className="text-gray-500" />;
  }
};

export const EmailClient: React.FC<EmailClientProps> = ({ 
  emails, 
  selectedEmailId, 
  checkedEmailIds,
  onSelectEmail, 
  onToggleCheck,
  onAttachmentClick
}) => {
  const selectedEmail = emails.find(e => e.id === selectedEmailId);

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0C1014] overflow-hidden text-[#8F949A]">
      {/* Mock Header (Gmail-like) */}
      <div className="h-16 border-b border-[#1E2329] flex items-center px-4 bg-[#0C1014] justify-between">
        <div className="flex items-center gap-4">
          <Menu className="text-white cursor-pointer" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-6 bg-red-500 rounded text-white text-xs flex items-center justify-center font-bold">M</div>
            <span className="text-xl font-medium text-white tracking-tight">Gmail</span>
          </div>
        </div>
        
        <div className="flex-1 max-w-2xl mx-4">
           <div className="bg-[#1E2329] rounded-lg h-12 flex items-center px-4 gap-3">
             <Search className="text-[#8F949A]" size={20} />
             <input type="text" placeholder="Search mail" className="bg-transparent border-none outline-none text-white w-full placeholder-[#8F949A]" />
           </div>
        </div>

        <div className="flex items-center gap-4 text-white">
           <HelpCircle size={20} />
           <Settings size={20} />
           <Grid size={20} />
           <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-sm font-bold">U</div>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Nav (Mock) */}
        <div className="w-64 pr-4 hidden lg:flex flex-col pt-4 gap-2">
           <div className="px-4 mb-4">
             <button className="bg-[#2D7FF9] text-white rounded-2xl h-14 w-36 flex items-center justify-center gap-2 font-medium shadow-md hover:shadow-lg transition-shadow">
               <span className="text-2xl">+</span> Compose
             </button>
           </div>
           
           <div className="flex flex-col">
              <div className="bg-[#1E2329] rounded-r-full px-6 py-2 text-white font-bold flex justify-between items-center cursor-pointer border-l-4 border-l-[#2D7FF9]">
                <span>Inbox</span>
                <span className="text-xs">12</span>
              </div>
              <div className="px-6 py-2 hover:bg-[#1E2329] rounded-r-full cursor-pointer flex justify-between items-center">
                 <span>Starred</span>
              </div>
              <div className="px-6 py-2 hover:bg-[#1E2329] rounded-r-full cursor-pointer flex justify-between items-center">
                 <span>Snoozed</span>
              </div>
              <div className="px-6 py-2 hover:bg-[#1E2329] rounded-r-full cursor-pointer flex justify-between items-center">
                 <span>Sent</span>
              </div>
           </div>
        </div>

        {/* Email List */}
        <div className="w-96 flex flex-col overflow-y-auto bg-[#0C1014] border-r border-[#1E2329]">
          {emails.map((email) => {
             const isChecked = checkedEmailIds.has(email.id);
             const isSelected = selectedEmailId === email.id;
             const hasAttachments = email.attachments && email.attachments.length > 0;
             
             return (
              <div
                key={email.id}
                className={`flex gap-3 p-3 border-b border-[#1E2329] hover:bg-[#13171C] group cursor-pointer transition-colors relative ${
                  isSelected ? 'bg-[#18212C] border-l-2 border-l-[#2D7FF9]' : 'border-l-2 border-l-transparent'
                }`}
                onClick={() => onSelectEmail(email.id)}
              >
                {/* Checkbox & Star area */}
                <div className="flex flex-col items-center gap-3 pt-1" onClick={(e) => e.stopPropagation()}>
                  <input 
                    type="checkbox" 
                    checked={isChecked}
                    onChange={() => onToggleCheck(email.id)}
                    className="appearance-none w-4 h-4 border-2 border-[#8F949A] rounded-sm bg-transparent checked:bg-[#2D7FF9] checked:border-[#2D7FF9] cursor-pointer" 
                  />
                  <Star size={16} className="text-[#8F949A] hover:text-yellow-500 cursor-pointer" />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center mb-1">
                     <span className={`text-sm truncate ${isSelected ? 'text-white font-bold' : 'text-[#E3E3E3] font-medium'}`}>
                       {email.sender}
                     </span>
                     <span className="text-xs text-[#8F949A] whitespace-nowrap ml-2">{email.date}</span>
                  </div>
                  <div className="text-sm text-[#E3E3E3] truncate mb-0.5">{email.subject}</div>
                  <div className="text-xs text-[#8F949A] line-clamp-2 leading-relaxed">
                    {email.body.replace(/\n/g, ' ')}
                  </div>
                  {hasAttachments && (
                    <div className="mt-2 flex gap-1">
                      <div className="bg-[#1E2329] border border-[#2D2D2D] rounded-full px-2 py-0.5 flex items-center gap-1 w-fit">
                        <Paperclip size={10} className="text-[#8F949A]" />
                        <span className="text-[10px] text-[#8F949A]">{email.attachments?.length} file{email.attachments?.length !== 1 ? 's' : ''}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
          )})}
        </div>

        {/* Email Detail View */}
        <div className="flex-1 overflow-y-auto bg-[#0C1014] rounded-tl-2xl border-l border-t border-[#1E2329] mr-2 mt-2 p-6 shadow-inner">
          {selectedEmail ? (
            <div className="max-w-4xl mx-auto text-[#E3E3E3]">
              <div className="flex items-center justify-between mb-8">
                <h1 className="text-2xl font-normal text-white">{selectedEmail.subject}</h1>
                <div className="flex gap-2">
                   <span className="bg-[#1E2329] px-2 py-1 text-xs rounded text-[#8F949A]">Inbox</span>
                   <span className="bg-[#1E2329] px-2 py-1 text-xs rounded text-[#8F949A]">x</span>
                </div>
              </div>

              <div className="flex items-start mb-8 gap-4">
                <div className="w-10 h-10 rounded-full bg-[#2D7FF9] text-white flex items-center justify-center font-bold text-lg shadow-lg">
                  {selectedEmail.sender.charAt(0)}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-baseline">
                     <div className="font-bold text-white text-sm">{selectedEmail.sender} <span className="text-[#8F949A] font-normal text-xs">&lt;{selectedEmail.sender.toLowerCase().replace(' ', '.')}@example.com&gt;</span></div>
                     <div className="text-xs text-[#8F949A]">{selectedEmail.date}</div>
                  </div>
                  <div className="text-xs text-[#8F949A]">to me</div>
                </div>
              </div>
              
              <div className="prose prose-invert max-w-none text-[#E3E3E3] leading-relaxed whitespace-pre-wrap font-light text-sm min-h-[200px]">
                {selectedEmail.body}
              </div>

              {/* Attachments Section */}
              {selectedEmail.attachments && selectedEmail.attachments.length > 0 && (
                <div className="mt-8 pt-4 border-t border-[#1E2329]">
                  <h3 className="text-sm font-semibold text-[#8F949A] mb-3">{selectedEmail.attachments.length} Attachments</h3>
                  <div className="flex flex-wrap gap-4">
                    {selectedEmail.attachments.map((att) => (
                      <div 
                        key={att.id}
                        onClick={() => onAttachmentClick(att)}
                        className="group relative bg-[#13171C] border border-[#1E2329] hover:border-[#2D7FF9] rounded-lg p-3 w-48 cursor-pointer transition-all hover:bg-[#18212C]"
                      >
                        <div className="flex items-center gap-3 mb-2">
                          <div className="p-2 bg-[#0C1014] rounded-lg">
                            {getFileIcon(att.type)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium text-[#E3E3E3] truncate" title={att.name}>{att.name}</div>
                            <div className="text-xs text-[#8F949A]">{att.size}</div>
                          </div>
                        </div>
                        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="bg-[#2D7FF9] p-1 rounded-full text-white">
                            <Grid size={12} />
                          </div>
                        </div>
                        <div className="mt-2 h-16 bg-[#0C1014] rounded flex items-center justify-center overflow-hidden relative">
                           {/* Mock preview */}
                           <div className="absolute inset-0 bg-[#1E2329] opacity-50"></div>
                           <span className="relative z-10 text-[10px] text-[#8F949A] font-medium uppercase tracking-wider">{att.type}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="mt-12 flex gap-4">
                <button className="border border-[#8F949A] text-[#8F949A] px-6 py-2 rounded-full text-sm hover:bg-[#1E2329] hover:text-white transition-colors">
                  Reply
                </button>
                <button className="border border-[#8F949A] text-[#8F949A] px-6 py-2 rounded-full text-sm hover:bg-[#1E2329] hover:text-white transition-colors">
                  Forward
                </button>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-[#8F949A]">
              <div className="w-20 h-20 rounded-full bg-[#1E2329] flex items-center justify-center mb-4">
                 <Menu size={32} />
              </div>
              <p>Select an email to read</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};