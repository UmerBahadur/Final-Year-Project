import { KEYS, ENDPOINTS } from '../constants';

export const summarizeWithBART = async (text: string): Promise<string> => {
  try {
    const response = await fetch(ENDPOINTS.HUGGINGFACE_BART, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${KEYS.HUGGINGFACE}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ inputs: text })
    });

    if (!response.ok) {
      throw new Error(`HF API Error: ${response.statusText}`);
    }

    const result = await response.json();
    // Handling different potential HF Inference endpoint return shapes
    if (result && result.summary) {
      return result.summary;
    } else if (Array.isArray(result) && result[0]?.summary_text) {
      return result[0].summary_text;
    } else {
      return JSON.stringify(result);
    }
  } catch (error) {
    console.error("BART Summarization Error:", error);
    throw error;
  }
};
