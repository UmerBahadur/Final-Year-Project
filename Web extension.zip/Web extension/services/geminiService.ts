import { GoogleGenAI } from "@google/genai";
import { KEYS, GEMINI_MODEL } from '../constants';

// Initialize the Gemini SDK
// Note: In a real app, use process.env.API_KEY. Here we use the user provided constant for the prototype.
const ai = new GoogleGenAI({ apiKey: KEYS.GEMINI });

export const summarizeWithGemini = async (text: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: `Please summarize the following email:\n\n${text}`,
    });
    
    return response.text || "No response text found.";
  } catch (error) {
    console.error("Gemini Summarization Error:", error);
    throw error;
  }
};

export const generateReplyWithGemini = async (emailContext: string, userPrompt: string): Promise<string> => {
  try {
    const prompt = `
    You are an email assistant.
    
    EMAIL CONTEXT:
    ${emailContext}
    
    USER INSTRUCTION:
    ${userPrompt}
    
    Please draft a professional email reply based on the instruction above. Return only the email body text.
    `;

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
    });

    return response.text || "Could not generate reply.";
  } catch (error) {
    console.error("Gemini Reply Error:", error);
    throw error;
  }
};

export const generateReplySuggestions = async (emailContext: string): Promise<string[]> => {
  try {
    // We ask for JSON array of strings
    const prompt = `
    Analyze the following email and provide 3 short, actionable instructions (3-5 words max) that a user might give to an AI to generate a reply. 
    Examples: "Accept the invitation", "Ask for more details", "Politely decline".
    
    EMAIL:
    ${emailContext}
    
    Return ONLY a JSON array of strings. Example: ["Suggestion 1", "Suggestion 2", "Suggestion 3"]
    `;

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });
    
    const text = response.text || "[]";
    try {
      const suggestions = JSON.parse(text);
      if (Array.isArray(suggestions)) {
        return suggestions.slice(0, 3);
      }
      return [];
    } catch (e) {
      console.error("Failed to parse suggestions JSON", e);
      return [];
    }
  } catch (error) {
    console.error("Gemini Suggestions Error:", error);
    return [];
  }
};