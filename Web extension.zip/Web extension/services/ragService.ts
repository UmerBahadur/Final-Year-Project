const RAG_API_ENDPOINT = "https://y4a0zixbcc.execute-api.us-east-1.amazonaws.com/prod/process";

// Convert file to base64
function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(',')[1]); // Remove data:application/pdf;base64,
    };
    reader.onerror = error => reject(error);
  });
}

export const summarizeFileWithRAG = async (file: File): Promise<string> => {
  try {
    const base64File = await fileToBase64(file);
    
    const requestBody = {
      file: base64File,
      mode: "summary"
    };
    
    const response = await fetch(RAG_API_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const result = await response.json();
    return result.result || "No summary generated.";
    
  } catch (error) {
    console.error('Error processing file with RAG:', error);
    throw error;
  }
};