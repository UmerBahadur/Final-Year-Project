// Gmail Content Script - Injects AI Companion Sidebar
let sidebarInjected = false;

function injectSidebar() {
  if (sidebarInjected) return;
  
  // Create sidebar container
  const sidebar = document.createElement('div');
  sidebar.id = 'ai-companion-sidebar';
  sidebar.innerHTML = `
    <div style="
      position: fixed;
      top: 0;
      right: 0;
      width: 400px;
      height: 100vh;
      background: #0C1014;
      border-left: 1px solid #1E2329;
      z-index: 10000;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      color: #E3E3E3;
      display: flex;
      flex-direction: column;
    ">
      <!-- Header -->
      <div style="
        height: 64px;
        border-bottom: 1px solid #1E2329;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 20px;
        background: #0C1014;
      ">
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="
            width: 32px;
            height: 32px;
            background: #2D7FF9;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
          ">✨</div>
          <span style="font-weight: bold; color: white;">AI Companion</span>
        </div>
        <button id="close-sidebar" style="
          background: none;
          border: none;
          color: #8F949A;
          cursor: pointer;
          font-size: 20px;
        ">×</button>
      </div>

      <!-- Tabs -->
      <div style="
        display: flex;
        padding: 8px;
        gap: 8px;
        border-bottom: 1px solid #1E2329;
      ">
        <button class="tab-btn active" data-tab="summary" style="
          flex: 1;
          padding: 10px;
          font-size: 12px;
          font-weight: 600;
          border-radius: 8px;
          border: none;
          cursor: pointer;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          background: #1E2329;
          color: #2D7FF9;
        ">Summary</button>
        <button class="tab-btn" data-tab="reply" style="
          flex: 1;
          padding: 10px;
          font-size: 12px;
          font-weight: 600;
          border-radius: 8px;
          border: none;
          cursor: pointer;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          background: transparent;
          color: #8F949A;
        ">Reply</button>
      </div>

      <!-- Content -->
      <div style="flex: 1; overflow-y: auto; padding: 20px;">
        <div id="summary-tab" class="tab-content">
          <div style="
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 12px;
            color: #8F949A;
            background: #13171C;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #1E2329;
            margin-bottom: 24px;
          ">
            <span id="email-count">Select an email to summarize</span>
          </div>
          
          <button id="summarize-btn" style="
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: none;
            background: #2D7FF9;
            color: white;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-bottom: 24px;
          " disabled>
            ✨ Summarize Email
          </button>
          
          <div id="summary-result" style="
            background: #13171C;
            border: 1px solid #1E2329;
            border-radius: 12px;
            padding: 16px;
            font-size: 14px;
            line-height: 1.5;
            display: none;
          "></div>
        </div>

        <div id="reply-tab" class="tab-content" style="display: none;">
          <textarea id="reply-prompt" placeholder="E.g., Accept the invitation and ask about timeline..." style="
            width: 100%;
            height: 120px;
            border: 1px solid #1E2329;
            border-radius: 12px;
            padding: 16px;
            font-size: 14px;
            background: #13171C;
            color: white;
            resize: none;
            margin-bottom: 16px;
          "></textarea>
          
          <button id="generate-reply-btn" style="
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: none;
            background: #2D7FF9;
            color: white;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-bottom: 24px;
          " disabled>
            📤 Generate Reply
          </button>
          
          <div id="reply-result" style="
            background: #13171C;
            border: 1px solid #1E2329;
            border-radius: 12px;
            padding: 16px;
            font-size: 14px;
            line-height: 1.5;
            white-space: pre-wrap;
            display: none;
          "></div>
        </div>
      </div>
    </div>
  `;
  
  document.body.appendChild(sidebar);
  sidebarInjected = true;
  
  // Add event listeners
  setupEventListeners();
  
  // Adjust Gmail layout
  adjustGmailLayout();
}

function setupEventListeners() {
  // Close sidebar
  document.getElementById('close-sidebar').onclick = () => {
    document.getElementById('ai-companion-sidebar').remove();
    sidebarInjected = false;
    resetGmailLayout();
  };
  
  // Tab switching
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.onclick = () => switchTab(btn.dataset.tab);
  });
  
  // Summarize button
  document.getElementById('summarize-btn').onclick = summarizeCurrentEmail;
  
  // Generate reply button
  document.getElementById('generate-reply-btn').onclick = generateReply;
  
  // Monitor email selection
  monitorEmailSelection();
}

function switchTab(tabName) {
  // Update buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.style.background = btn.dataset.tab === tabName ? '#1E2329' : 'transparent';
    btn.style.color = btn.dataset.tab === tabName ? '#2D7FF9' : '#8F949A';
  });
  
  // Update content
  document.querySelectorAll('.tab-content').forEach(content => {
    content.style.display = content.id === `${tabName}-tab` ? 'block' : 'none';
  });
}

function adjustGmailLayout() {
  const gmailContainer = document.querySelector('[role="main"]') || document.body;
  gmailContainer.style.marginRight = '400px';
  gmailContainer.style.transition = 'margin-right 0.3s ease';
}

function resetGmailLayout() {
  const gmailContainer = document.querySelector('[role="main"]') || document.body;
  gmailContainer.style.marginRight = '0';
}

function monitorEmailSelection() {
  // Watch for email selection changes
  const observer = new MutationObserver(() => {
    updateEmailStatus();
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Initial check
  updateEmailStatus();
}

function updateEmailStatus() {
  const emailContent = getCurrentEmailContent();
  const countElement = document.getElementById('email-count');
  const summarizeBtn = document.getElementById('summarize-btn');
  const replyBtn = document.getElementById('generate-reply-btn');
  
  if (emailContent) {
    countElement.textContent = '1 Email Selected';
    summarizeBtn.disabled = false;
    replyBtn.disabled = false;
    summarizeBtn.style.background = '#2D7FF9';
    replyBtn.style.background = '#2D7FF9';
  } else {
    countElement.textContent = 'Select an email to summarize';
    summarizeBtn.disabled = true;
    replyBtn.disabled = true;
    summarizeBtn.style.background = '#1E2329';
    replyBtn.style.background = '#1E2329';
  }
}

function getCurrentEmailContent() {
  // Try multiple selectors for Gmail email content
  const selectors = [
    '[data-message-id] .ii.gt .a3s.aiL',
    '.ii.gt .a3s.aiL',
    '[role="listitem"] .a3s.aiL',
    '.adn.ads .a3s.aiL'
  ];
  
  for (const selector of selectors) {
    const element = document.querySelector(selector);
    if (element && element.textContent.trim()) {
      return element.textContent.trim();
    }
  }
  return null;
}

async function summarizeCurrentEmail() {
  const emailContent = getCurrentEmailContent();
  if (!emailContent) return;
  
  const btn = document.getElementById('summarize-btn');
  const result = document.getElementById('summary-result');
  
  btn.innerHTML = '⏳ Summarizing...';
  btn.disabled = true;
  
  try {
    const summary = await callGeminiAPI(emailContent, 'summarize');
    result.textContent = summary;
    result.style.display = 'block';
  } catch (error) {
    result.textContent = 'Error: ' + error.message;
    result.style.display = 'block';
  }
  
  btn.innerHTML = '✨ Summarize Email';
  btn.disabled = false;
}

async function generateReply() {
  const emailContent = getCurrentEmailContent();
  const prompt = document.getElementById('reply-prompt').value;
  
  if (!emailContent || !prompt) return;
  
  const btn = document.getElementById('generate-reply-btn');
  const result = document.getElementById('reply-result');
  
  btn.innerHTML = '⏳ Generating...';
  btn.disabled = true;
  
  try {
    const reply = await callGeminiAPI(emailContent, 'reply', prompt);
    result.textContent = reply;
    result.style.display = 'block';
  } catch (error) {
    result.textContent = 'Error: ' + error.message;
    result.style.display = 'block';
  }
  
  btn.innerHTML = '📤 Generate Reply';
  btn.disabled = false;
}

async function callGeminiAPI(emailContent, mode, prompt = '') {
  const API_KEY = 'AIzaSyA3kZJx-Bc17cvRQyA-ywnXv-ky-SaCjYs';
  
  let requestPrompt;
  if (mode === 'summarize') {
    requestPrompt = `Please summarize the following email:\n\n${emailContent}`;
  } else {
    requestPrompt = `You are an email assistant.\n\nEMAIL CONTEXT:\n${emailContent}\n\nUSER INSTRUCTION:\n${prompt}\n\nPlease draft a professional email reply based on the instruction above. Return only the email body text.`;
  }
  
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${API_KEY}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      contents: [{
        parts: [{
          text: requestPrompt
        }]
      }]
    })
  });
  
  if (!response.ok) {
    throw new Error('API request failed');
  }
  
  const data = await response.json();
  return data.candidates[0].content.parts[0].text;
}

// Initialize when Gmail loads
function init() {
  if (window.location.hostname === 'mail.google.com') {
    // Wait for Gmail to load
    setTimeout(() => {
      if (!sidebarInjected) {
        injectSidebar();
      }
    }, 2000);
  }
}

// Run on page load and navigation
init();

// Handle Gmail SPA navigation
let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    setTimeout(init, 1000);
  }
}).observe(document, { subtree: true, childList: true });