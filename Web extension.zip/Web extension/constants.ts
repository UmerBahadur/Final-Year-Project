// NOTE: In a production environment, never expose API keys on the client side.
// These should be proxied through a backend server.
// Using them here directly as per the prototype requirements.

export const KEYS = {
  HUGGINGFACE: "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",
  GROQ: "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",
  GEMINI: "AIzaSyA3kZJx-Bc17cvRQyA-ywnXv-ky-SaCjYs", // Assuming this is valid, otherwise use process.env.API_KEY if meant for the developer environment
};

export const ENDPOINTS = {
  HUGGINGFACE_BART: "https://d4n5tc6a6ltr3pef.us-east-1.aws.endpoints.huggingface.cloud",
  GROQ_CHAT: "https://api.groq.com/openai/v1/chat/completions",
  GROQ_AUDIO: "https://api.groq.com/openai/v1/audio/transcriptions",
};

export const GROQ_MODELS = {
  // Mapping "GPT OSS 120B" to a high-parameter open model available on Groq (e.g., Mixtral or similar if specific ID isn't known, using Mixtral as proxy)
  GPT_OSS_120B: "mixtral-8x7b-32768", 
  LLAMA_3_3_70B: "llama-3.3-70b-versatile",
};

export const GEMINI_MODEL = "gemini-2.5-flash";