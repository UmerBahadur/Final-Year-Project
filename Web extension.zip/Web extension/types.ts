export enum SummaryProvider {
  HUGGINGFACE_BART = "Custom BART (HuggingFace)",
  GROQ_GPT_OSS = "GPT OSS 120B (Groq)",
  GROQ_LLAMA = "Llama 3.3 70B (Groq)",
  GEMINI = "Gemini 2.5 Flash",
}

export interface Attachment {
  id: string;
  name: string;
  type: 'pdf' | 'doc' | 'image' | 'sheet';
  size: string;
}

export interface Email {
  id: string;
  sender: string;
  subject: string;
  body: string;
  date: string;
  avatar: string;
  attachments?: Attachment[];
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}