// Web Extension Example - Chrome/Firefox Extension
// Use this in your content script or popup script

const API_ENDPOINT = "https://y4a0zixbcc.execute-api.us-east-1.amazonaws.com/prod/process";

// Function to convert file to base64
function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result.split(',')[1]); // Remove data:application/pdf;base64,
        reader.onerror = error => reject(error);
    });
}

// Function to call your PDF RAG API
async function processPDF(pdfFile, mode, question = "") {
    try {
        // Convert PDF to base64
        const base64PDF = await fileToBase64(pdfFile);
        
        // Prepare request body
        const requestBody = {
            file: base64PDF,
            mode: mode // "summary" or "ask"
        };
        
        // Add question if in Q&A mode
        if (mode === "ask" && question) {
            requestBody.question = question;
        }
        
        // Make API call
        const response = await fetch(API_ENDPOINT, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        return result.result;
        
    } catch (error) {
        console.error('Error processing PDF:', error);
        throw error;
    }
}

// Example usage in your extension
document.addEventListener('DOMContentLoaded', function() {
    
    // Example 1: File input handler
    const fileInput = document.getElementById('pdf-input');
    const summaryBtn = document.getElementById('summary-btn');
    const askBtn = document.getElementById('ask-btn');
    const questionInput = document.getElementById('question-input');
    const resultDiv = document.getElementById('result');
    
    summaryBtn.addEventListener('click', async () => {
        if (!fileInput.files[0]) {
            alert('Please select a PDF file');
            return;
        }
        
        resultDiv.textContent = 'Processing... (may take 2-3 minutes for first request)';
        
        try {
            const summary = await processPDF(fileInput.files[0], 'summary');
            resultDiv.textContent = summary;
        } catch (error) {
            resultDiv.textContent = 'Error: ' + error.message;
        }
    });
    
    askBtn.addEventListener('click', async () => {
        if (!fileInput.files[0]) {
            alert('Please select a PDF file');
            return;
        }
        
        const question = questionInput.value.trim();
        if (!question) {
            alert('Please enter a question');
            return;
        }
        
        resultDiv.textContent = 'Processing... (may take 2-3 minutes for first request)';
        
        try {
            const answer = await processPDF(fileInput.files[0], 'ask', question);
            resultDiv.textContent = answer;
        } catch (error) {
            resultDiv.textContent = 'Error: ' + error.message;
        }
    });
});

// Example 2: Process PDF from URL (if you have PDF URL)
async function processPDFFromURL(pdfUrl, mode, question = "") {
    try {
        // Fetch PDF as blob
        const response = await fetch(pdfUrl);
        const blob = await response.blob();
        
        // Convert blob to file
        const file = new File([blob], 'document.pdf', { type: 'application/pdf' });
        
        // Process using existing function
        return await processPDF(file, mode, question);
        
    } catch (error) {
        console.error('Error processing PDF from URL:', error);
        throw error;
    }
}

// Example 3: Drag and drop handler
function setupDragAndDrop() {
    const dropZone = document.getElementById('drop-zone');
    
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('drag-over');
    });
    
    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('drag-over');
    });
    
    dropZone.addEventListener('drop', async (e) => {
        e.preventDefault();
        dropZone.classList.remove('drag-over');
        
        const files = e.dataTransfer.files;
        if (files.length > 0 && files[0].type === 'application/pdf') {
            try {
                const summary = await processPDF(files[0], 'summary');
                document.getElementById('result').textContent = summary;
            } catch (error) {
                document.getElementById('result').textContent = 'Error: ' + error.message;
            }
        }
    });
}

// Call this when your extension loads
setupDragAndDrop();