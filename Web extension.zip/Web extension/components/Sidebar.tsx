import React, { useState, useRef, useEffect } from 'react';
import { Mic, Send, FileText, X, ChevronDown, Sparkles, Paperclip, Play, Square, CheckSquare, Lightbulb } from 'lucide-react';
import { SummaryProvider, Email, Attachment } from '../types';
import { summarizeWithBART } from '../services/huggingFaceService';
import { summarizeWithGroq, transcribeAudioWithGroq } from '../services/groqService';
import { summarizeWithGemini, generateReplyWithGemini, generateReplySuggestions } from '../services/geminiService';
import { summarizeFileWithRAG } from '../services/ragService';
import { GROQ_MODELS } from '../constants';

interface SidebarProps {
  targetEmails: Email[];
  selectedFile: Attachment | null;
  activeTab: 'summary' | 'reply' | 'files';
  setActiveTab: (tab: 'summary' | 'reply' | 'files') => void;
}

interface BatchSummaryResult {
  emailId: string;
  subject: string;
  summary: string;
  status: 'pending' | 'loading' | 'done' | 'error';
}

export const Sidebar: React.FC<SidebarProps> = ({ targetEmails, selectedFile, activeTab, setActiveTab }) => {
  // Summary State
  const [selectedProvider, setSelectedProvider] = useState<SummaryProvider>(SummaryProvider.GEMINI);
  const [batchResults, setBatchResults] = useState<BatchSummaryResult[]>([]);
  const [isSummarizing, setIsSummarizing] = useState(false);

  // Reset results when selection changes significantly
  useEffect(() => {
    setBatchResults([]);
  }, [targetEmails.length]);

  // Reply State
  const [replyPrompt, setReplyPrompt] = useState("");
  const [generatedReply, setGeneratedReply] = useState("");
  const [isReplying, setIsReplying] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  // File State
  const [fileSummary, setFileSummary] = useState("");
  const [isProcessingFile, setIsProcessingFile] = useState(false);

  // Load suggestions when Reply tab is active and single email selected
  useEffect(() => {
    if (activeTab === 'reply' && targetEmails.length === 1) {
        setLoadingSuggestions(true);
        generateReplySuggestions(targetEmails[0].body)
            .then(s => setSuggestions(s))
            .catch(err => console.error(err))
            .finally(() => setLoadingSuggestions(false));
    } else {
        setSuggestions([]);
    }
  }, [activeTab, targetEmails]);

  // Reset file summary when file changes
  useEffect(() => {
    setFileSummary("");
  }, [selectedFile]);

  const handleSummarize = async () => {
    if (targetEmails.length === 0) return;
    
    setIsSummarizing(true);
    
    // Initialize results state
    const initialResults: BatchSummaryResult[] = targetEmails.map(email => ({
      emailId: email.id,
      subject: email.subject,
      summary: "",
      status: 'pending'
    }));
    setBatchResults(initialResults);

    // Process one by one
    const newResults = [...initialResults];
    
    for (let i = 0; i < newResults.length; i++) {
        const item = newResults[i];
        
        // Update status to loading
        newResults[i] = { ...item, status: 'loading' };
        setBatchResults([...newResults]);

        try {
            const contentToSummarize = targetEmails.find(e => e.id === item.emailId)?.body || "";
            let resultText = "";
            
            switch (selectedProvider) {
                case SummaryProvider.HUGGINGFACE_BART:
                resultText = await summarizeWithBART(contentToSummarize);
                break;
                case SummaryProvider.GROQ_GPT_OSS:
                resultText = await summarizeWithGroq(contentToSummarize, GROQ_MODELS.GPT_OSS_120B);
                break;
                case SummaryProvider.GROQ_LLAMA:
                resultText = await summarizeWithGroq(contentToSummarize, GROQ_MODELS.LLAMA_3_3_70B);
                break;
                case SummaryProvider.GEMINI:
                resultText = await summarizeWithGemini(contentToSummarize);
                break;
            }

            newResults[i] = { ...item, summary: resultText, status: 'done' };
        } catch (e) {
            newResults[i] = { ...item, summary: "Failed to generate summary.", status: 'error' };
        }
        
        // Update state after each completion
        setBatchResults([...newResults]);
    }

    setIsSummarizing(false);
  };

  const handleStartRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      const audioChunks: BlobPart[] = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunks.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
        try {
            setReplyPrompt((prev) => prev + " (Transcribing...)");
            const text = await transcribeAudioWithGroq(audioBlob);
            setReplyPrompt((prev) => prev.replace(" (Transcribing...)", "") + " " + text);
        } catch (e) {
            console.error(e);
            setReplyPrompt((prev) => prev.replace(" (Transcribing...)", "") + " [Error transcribing]");
        }
      };

      mediaRecorder.start();
      mediaRecorderRef.current = mediaRecorder;
      setIsRecording(true);
    } catch (err) {
      console.error("Error accessing microphone:", err);
      alert("Microphone access denied or not available.");
    }
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const handleGenerateReply = async () => {
    if (!replyPrompt || targetEmails.length !== 1) return;

    setIsReplying(true);
    try {
      const result = await generateReplyWithGemini(targetEmails[0].body, replyPrompt);
      setGeneratedReply(result);
    } catch (e) {
      setGeneratedReply("Error generating reply.");
    } finally {
      setIsReplying(false);
    }
  };

  const handleSummarizeFile = async () => {
    if (!selectedFile) return;

    setIsProcessingFile(true);
    setFileSummary("");
    
    try {
      // Create a mock file object for the selected attachment
      // In a real implementation, you'd fetch the actual file content
      const mockFile = new File(["mock content"], selectedFile.name, { 
        type: selectedFile.type === 'pdf' ? 'application/pdf' : 'application/msword' 
      });
      
      const summary = await summarizeFileWithRAG(mockFile);
      setFileSummary(summary);
    } catch (error) {
      setFileSummary("Error: Unable to process file. " + (error as Error).message);
    } finally {
      setIsProcessingFile(false);
    }
  };

  const isMultiple = targetEmails.length > 1;

  return (
    <div className="w-[400px] h-full bg-[#0C1014] border-l border-[#1E2329] shadow-2xl flex flex-col font-sans z-50 text-[#E3E3E3]">
      {/* Extension Header */}
      <div className="h-16 border-b border-[#1E2329] flex items-center justify-between px-5 bg-[#0C1014]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#2D7FF9] rounded-lg flex items-center justify-center text-white font-bold shadow-lg shadow-blue-900/20">
            <Sparkles size={18} fill="currentColor" />
          </div>
          <span className="font-bold text-white tracking-tight">AI Companion</span>
        </div>
        <button className="text-[#8F949A] hover:text-white transition-colors">
          <X size={20} />
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="flex p-2 bg-[#0C1014] gap-2 border-b border-[#1E2329]">
        {(['summary', 'reply', 'files'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-2.5 text-xs font-semibold rounded-lg transition-all uppercase tracking-wide ${
              activeTab === tab 
                ? 'bg-[#1E2329] text-[#2D7FF9] shadow-sm ring-1 ring-[#2D7FF9]/20' 
                : 'text-[#8F949A] hover:bg-[#13171C] hover:text-white'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto p-5 custom-scrollbar">
        
        {/* === SUMMARY TAB === */}
        {activeTab === 'summary' && (
          <div className="space-y-6">
            
            {/* Selection Info */}
            <div className="flex items-center justify-between text-xs text-[#8F949A] bg-[#13171C] p-3 rounded-lg border border-[#1E2329]">
                <div className="flex items-center gap-2">
                    <CheckSquare size={14} className={targetEmails.length > 0 ? "text-[#2D7FF9]" : "text-[#8F949A]"} />
                    <span>{targetEmails.length} Email{targetEmails.length !== 1 ? 's' : ''} Selected</span>
                </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-[#8F949A] uppercase tracking-wider mb-2">
                AI Model
              </label>
              <div className="relative">
                <select
                  value={selectedProvider}
                  onChange={(e) => setSelectedProvider(e.target.value as SummaryProvider)}
                  className="w-full appearance-none bg-[#13171C] border border-[#1E2329] text-white py-3 px-4 pr-10 rounded-lg leading-tight focus:outline-none focus:border-[#2D7FF9] focus:ring-1 focus:ring-[#2D7FF9] text-sm transition-all"
                >
                  {Object.values(SummaryProvider).map((p) => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-[#8F949A]">
                  <ChevronDown size={14} />
                </div>
              </div>
            </div>

            <button
              onClick={handleSummarize}
              disabled={isSummarizing || targetEmails.length === 0}
              className={`w-full py-3 rounded-lg flex items-center justify-center gap-2 text-sm font-bold text-white transition-all shadow-lg ${
                isSummarizing || targetEmails.length === 0
                  ? 'bg-[#1E2329] text-[#8F949A] cursor-not-allowed shadow-none' 
                  : 'bg-[#2D7FF9] hover:bg-blue-600 shadow-blue-600/20 hover:shadow-blue-600/40'
              }`}
            >
              {isSummarizing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  {isMultiple ? 'Summarizing Batch...' : 'Thinking...'}
                </>
              ) : (
                <>
                  <Sparkles size={16} fill="currentColor" />
                  Summarize {isMultiple ? 'All' : 'Email'}
                </>
              )}
            </button>

            <div className="space-y-4">
              {batchResults.map((result, idx) => (
                  <div key={idx} className="animate-fade-in bg-[#13171C] border border-[#1E2329] rounded-xl overflow-hidden">
                      {isMultiple && (
                        <div className="bg-[#181D23] px-4 py-2 border-b border-[#1E2329] flex justify-between items-center">
                            <span className="text-xs font-medium text-white truncate max-w-[200px]">{result.subject}</span>
                            {result.status === 'done' && <span className="text-[10px] text-green-400">Done</span>}
                            {result.status === 'loading' && <span className="text-[10px] text-[#2D7FF9] animate-pulse">...</span>}
                            {result.status === 'pending' && <span className="text-[10px] text-[#8F949A]">Pending</span>}
                        </div>
                      )}
                      
                      {result.summary && (
                          <div className="p-4 text-sm text-[#E3E3E3] leading-relaxed whitespace-pre-line font-light">
                            {result.summary}
                          </div>
                      )}
                  </div>
              ))}
            </div>
          </div>
        )}

        {/* === REPLY TAB === */}
        {activeTab === 'reply' && (
          <div className="space-y-4 h-full flex flex-col">
            {targetEmails.length > 1 ? (
                 <div className="flex flex-col items-center justify-center h-40 text-[#8F949A] text-center border border-dashed border-[#1E2329] rounded-xl bg-[#13171C]">
                    <span className="mb-2">⚠️</span>
                    <p className="text-sm">Please select a single email <br/>to generate a reply.</p>
                 </div>
            ) : targetEmails.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-40 text-[#8F949A] text-center border border-dashed border-[#1E2329] rounded-xl bg-[#13171C]">
                    <p className="text-sm">Select an email to reply to.</p>
                 </div>
            ) : (
                <>
                <div className="flex-1 flex flex-col space-y-3">
                
                {/* AI Suggestions */}
                <div className="mb-2">
                   <div className="flex items-center gap-2 mb-2">
                        <Lightbulb size={12} className="text-[#2D7FF9]"/>
                        <span className="text-[10px] font-bold text-[#8F949A] uppercase tracking-wider">Suggested Actions</span>
                   </div>
                   <div className="flex flex-wrap gap-2">
                        {loadingSuggestions && (
                            <span className="text-xs text-[#8F949A] animate-pulse">Generating suggestions...</span>
                        )}
                        {!loadingSuggestions && suggestions.length === 0 && (
                            <span className="text-xs text-[#8F949A] italic">No suggestions available.</span>
                        )}
                        {suggestions.map((suggestion, idx) => (
                            <button 
                                key={idx}
                                onClick={() => setReplyPrompt(suggestion)}
                                className="text-xs bg-[#1E2329] hover:bg-[#2D7FF9] hover:text-white border border-[#2D2D2D] hover:border-[#2D7FF9] text-[#E3E3E3] px-3 py-1.5 rounded-full transition-all text-left"
                            >
                                {suggestion}
                            </button>
                        ))}
                   </div>
                </div>

                <label className="block text-[10px] font-bold text-[#8F949A] uppercase tracking-wider mt-2">
                    Your Instruction
                </label>
                
                <div className="relative">
                    <textarea
                    value={replyPrompt}
                    onChange={(e) => setReplyPrompt(e.target.value)}
                    placeholder="E.g., Accept the invitation and ask about the timeline..."
                    className="w-full h-32 border border-[#1E2329] rounded-xl p-4 text-sm focus:ring-1 focus:ring-[#2D7FF9] focus:border-[#2D7FF9] outline-none resize-none bg-[#13171C] text-white placeholder-[#8F949A]"
                    />
                    
                    {/* Mic Button */}
                    <button
                    onClick={isRecording ? handleStopRecording : handleStartRecording}
                    className={`absolute right-3 bottom-3 p-2.5 rounded-full transition-all shadow-lg ${
                        isRecording 
                        ? 'bg-red-500 text-white animate-pulse shadow-red-500/30' 
                        : 'bg-[#1E2329] text-[#8F949A] hover:bg-[#2D7FF9] hover:text-white border border-[#2D2D2D]'
                    }`}
                    title="Use Voice Input (Groq Whisper)"
                    >
                    {isRecording ? <Square size={14} fill="currentColor" /> : <Mic size={16} />}
                    </button>
                </div>

                <button
                    onClick={handleGenerateReply}
                    disabled={isReplying || !replyPrompt}
                    className={`w-full py-3 rounded-lg flex items-center justify-center gap-2 text-sm font-bold text-white transition-all shadow-lg ${
                    isReplying || !replyPrompt 
                        ? 'bg-[#1E2329] text-[#8F949A] cursor-not-allowed shadow-none' 
                        : 'bg-[#2D7FF9] hover:bg-blue-600 shadow-blue-600/20'
                    }`}
                >
                    {isReplying ? (
                    <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        Drafting...
                    </>
                    ) : (
                        <>
                        <Send size={16} />
                        Generate Reply
                        </>
                    )}
                </button>
                </div>

                {generatedReply && (
                <div className="mt-4 bg-[#13171C] border border-[#1E2329] rounded-xl shadow-lg overflow-hidden">
                    <div className="bg-[#181D23] px-4 py-2 border-b border-[#1E2329] flex justify-between items-center">
                    <span className="text-xs font-semibold text-[#8F949A]">Draft Preview</span>
                    <button 
                        onClick={() => {navigator.clipboard.writeText(generatedReply); alert('Copied!');}}
                        className="text-xs text-[#2D7FF9] hover:text-white transition-colors"
                    >
                        Copy
                    </button>
                    </div>
                    <div className="p-4 text-sm text-[#E3E3E3] whitespace-pre-wrap font-light">
                    {generatedReply}
                    </div>
                </div>
                )}
                </>
            )}
          </div>
        )}

        {/* === FILES TAB === */}
        {activeTab === 'files' && (
          <div className="h-full flex flex-col space-y-4">
            
            {selectedFile ? (
                <div className="w-full">
                    <div className="w-24 h-24 bg-[#13171C] rounded-2xl flex items-center justify-center text-[#2D7FF9] border border-[#1E2329] mx-auto mb-4 shadow-lg">
                        <FileText size={48} strokeWidth={1.5} />
                    </div>
                    <h3 className="font-semibold text-white text-lg text-center">{selectedFile.name}</h3>
                    <p className="text-sm text-[#8F949A] mt-1 text-center">{selectedFile.size} • {selectedFile.type.toUpperCase()}</p>
                    
                    <button 
                        onClick={handleSummarizeFile}
                        disabled={isProcessingFile}
                        className={`mt-8 w-full py-3 rounded-lg font-bold shadow-lg transition-all flex items-center justify-center gap-2 ${
                            isProcessingFile 
                                ? 'bg-[#1E2329] text-[#8F949A] cursor-not-allowed' 
                                : 'bg-[#2D7FF9] hover:bg-blue-600 text-white shadow-blue-900/20'
                        }`}
                    >
                        {isProcessingFile ? (
                            <>
                                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                                Processing...
                            </>
                        ) : (
                            <>
                                <Sparkles size={16} fill="currentColor"/>
                                Summarize File
                            </>
                        )}
                    </button>
                    
                    {fileSummary && (
                        <div className="mt-6 bg-[#13171C] border border-[#1E2329] rounded-xl overflow-hidden">
                            <div className="bg-[#181D23] px-4 py-2 border-b border-[#1E2329]">
                                <span className="text-xs font-semibold text-[#8F949A]">File Summary</span>
                            </div>
                            <div className="p-4 text-sm text-[#E3E3E3] leading-relaxed whitespace-pre-wrap font-light max-h-60 overflow-y-auto">
                                {fileSummary}
                            </div>
                        </div>
                    )}
                </div>
            ) : (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-6">
                    <div className="w-20 h-20 bg-[#13171C] rounded-full flex items-center justify-center text-[#2D7FF9] border border-[#1E2329]">
                        <FileText size={40} strokeWidth={1.5} />
                    </div>
                    <div>
                        <h3 className="font-semibold text-white">File Summarization</h3>
                        <p className="text-sm text-[#8F949A] mt-2 px-4 leading-relaxed">
                            Click on an attachment from an email to analyze it with AI.
                        </p>
                    </div>
                </div>
            )}
          </div>
        )}

      </div>
      
      {/* Footer */}
      <div className="p-4 bg-[#0C1014] border-t border-[#1E2329] text-center">
         <p className="text-[10px] text-[#4B5563] font-medium tracking-wide">POWERED BY GEMINI • GROQ • HUGGING FACE</p>
      </div>
    </div>
  );
};