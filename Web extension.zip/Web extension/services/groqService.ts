import { KEYS, ENDPOINTS } from '../constants';

export const summarizeWithGroq = async (text: string, modelId: string): Promise<string> => {
  try {
    const response = await fetch(ENDPOINTS.GROQ_CHAT, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${KEYS.GROQ}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        messages: [
          {
            role: "system",
            content: "You are a helpful assistant. Please summarize the following email text concisely."
          },
          {
            role: "user",
            content: text
          }
        ],
        model: modelId,
        temperature: 0.5
      })
    });

    if (!response.ok) {
      const errBody = await response.text();
      throw new Error(`Groq API Error: ${errBody}`);
    }

    const json = await response.json();
    return json.choices?.[0]?.message?.content || "No summary generated.";
  } catch (error) {
    console.error("Groq Summarization Error:", error);
    throw error;
  }
};

export const transcribeAudioWithGroq = async (audioBlob: Blob): Promise<string> => {
  try {
    const formData = new FormData();
    // Filename is required by Groq API
    formData.append("file", audioBlob, "recording.webm");
    formData.append("model", "whisper-large-v3");
    formData.append("response_format", "json");

    const response = await fetch(ENDPOINTS.GROQ_AUDIO, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${KEYS.GROQ}`,
      },
      body: formData
    });

    if (!response.ok) {
      throw new Error("Failed to transcribe audio via Groq");
    }

    const data = await response.json();
    return data.text || "";
  } catch (error) {
    console.error("Transcription Error:", error);
    throw error;
  }
};
